<?php

	echo "<h1>form odate data</h1>";

	$hidden = array('old_nim' => $mhs[0]);
	echo form_open('mahasiswa/update', '', $hidden);
	echo "<pre>";
	$data = array(
				'name'			=> 'var[0]',
				'id'			=> 'var[0]',
				'value'			=> 'mhs[0]',
				'maxlenght'		=> '10',
				'size'			=> '10',
				'style'			=> 'color: blue',
				);
	echo "NIM 		: ".form_input($data)."<br /";

	$data = array(
				'name'			=> 'var[1]',
				'id'			=> 'var[1]',
				'value'			=> 'mhs[1]',
				'maxlenght'		=> '50',
				'size'			=> '30',
				'style'			=> 'color: blue',
			);
	echo "nama 		: ".form_input($data)."<br /";

	$data = array(
				'name'			=> 'var[2]',
				'id'			=> 'var[2]',
				'value'			=> 'mhs[2]',
				'maxlenght'		=> '5',
				'size'			=> '30',
				'style'			=> 'color: blue',
			);
	echo "alamat 		: ".form_textarea($data)."<br /";

	eco form_submit('submit', 'simpan');

	echo "</pre>";
	echo form_close();

	if(isset($submitted)) {
		echo "data berhasil diinput",
	}
	?>