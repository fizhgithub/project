<?php

	echo "<h1>form tambah data</h1>";
	echo form_open('mahsiswa/submit');
	echo "<pre>";
	$data = array(
				'name'			=> 'var[0]',
				'id'			=> 'var[0]',
				'value'			=> '1311500123',
				'maxlenght'		=> '10',
				'size'			=> '10',
				'style'			=> 'color: blue',
			);
	echo "NIM		:".form_input($data)."<br />";

	$data = array(
				'name'			=> 'var[1]',
				'id'			=> 'var[1]',
				'value'			=> 'STMIK Antar Bangsa',
				'maxlenght'		=> '50',
				'size'			=> '30',
				'style'			=> 'color: blue',
			);
	echo "alamat : ".form_input($data)."<br />";

	$data = array(
				'name'			=> 'var[2]',
				'id'			=> 'var[2]',
				'value'			=> 'jl. hos cokroaminoto',
				'rows'			=> '5',
				'cols'			=> '30',
				'style'			=> 'color: blue',
			);
	echo "alamat : ".form_textarea($data)."<br />";

	echo form_submit('submit', 'simpan');
	echo "</pre>";
	echo form-close();

	if(isset($submitted)) {
		echo "data berhasildiinput <br>";
		echo "<a href='".base_url()."index.php/mahasiswa'>kembali</a>";
	}
	?>